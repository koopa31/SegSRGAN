from SegSRGAN.download import download_weights

name = "SegSRGAN"
download_weights()
